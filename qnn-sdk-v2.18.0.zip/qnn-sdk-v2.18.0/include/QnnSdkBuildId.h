//==============================================================================
//
// Copyright (c) 2021-2023 Qualcomm Technologies, Inc.
// All Rights Reserved.
// Confidential and Proprietary - Qualcomm Technologies, Inc.
//
//==============================================================================

//=============================================================================
// !!! This is an auto-generated file. Do NOT modify manually !!!
//=============================================================================

#ifndef QNN_SDK_BUILD_ID_H
#define QNN_SDK_BUILD_ID_H

/// QNN SDK build id
#define QNN_SDK_BUILD_ID "v2.18.0.231229151826_79175"

#endif  // QNN_SDK_BUILD_ID_H
