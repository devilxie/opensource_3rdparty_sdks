#!/bin/sh

FILEPATH=$(realpath $0)
CD=`dirname "$FILEPATH"`
cd $CD
CD=$(pwd)
OPENCV_DIR=$CD

TOOLCHAIN=$1


if [ -z "$TOOLCHAIN" ];then
   TOOLCHAIN=clang
fi

mkdir -p build_linux
cd build_linux


if [ "$TOOLCHAIN" = "clang" ];then

/usr/local/bin/cmake -DCMAKE_C_COMPLIER=clang -DCMAKE_CXX_COMPILER=clang++ \
    -DBUILD_ANDROID_PROJECTS=OFF \
    -DOPENCV_EXTRA_MODULES_PATH=/data/project/opencv-4.3.0/opencv_contrib-4.3.0/modules \
    -DOPENCV_ENABLE_NONFREE=YES \
    -DANDROID_STL=c++_static  \
    -DOPENCV_DIR=$OPENCV_DIR -DCMAKE_BUILD_TYPE=Release -DBUILD_ANDROID_EXAMPLES=OFF \
    -DBUILD_DOCS=OFF -DBUILD_EXAMPLES=OFF -DWITH_CUDA=OFF -DWITH_TBB=OFF -DWITH_IPP=OFF -DBUILD_opencv_world=ON \
    -DBUILD_FAT_JAVA_LIB=OFF \
    -DBUILD_opencv_videoio=ON \
    -DBUILD_opencv_gapi=OFF \
    -DOPENCV_FORCE_3RDPARTY_BUILD=ON \
    -DWITH_OPENCL=ON -DWITH_CUDA=OFF -DBUILD_SHARED_LIBS=ON -DBUILD_TESTS=OFF -DBUILD_PERF_TESTS=OFF  \
    -DBUILD_ZLIB=ON -DCV_TRACE=OFF -DCMAKE_INSTALL_PREFIX=$OPENCV_DIR/install \
    ../

elif [ "$TOOLCHAIN" = "gcc" ];then

/usr/local/bin/cmake -DCMAKE_C_COMPLIER=gcc -DCMAKE_CXX_COMPILER=g++ \
    -DBUILD_ANDROID_PROJECTS=OFF \
    -DOPENCV_EXTRA_MODULES_PATH=/data/project/opencv-4.3.0/opencv_contrib-4.3.0/modules \
    -DOPENCV_ENABLE_NONFREE=YES \
    -DBUILD_opencv_world=ON \
    -DBUILD_FAT_JAVA_LIB=OFF \
    -DBUILD_opencv_videoio=ON -DBUILD_opencv_gapi=OFF \
    -DANDROID_STL=gnustl_static  \
    -DOPENCV_FORCE_3RDPARTY_BUILD=ON \
    -DOPENCV_DIR=$OPENCV_DIR -DCMAKE_BUILD_TYPE=Release -DBUILD_ANDROID_EXAMPLES=OFF \
    -DBUILD_DOCS=OFF -DBUILD_EXAMPLES=OFF -DWITH_CUDA=OFF -DWITH_TBB=OFF -DWITH_IPP=OFF \
    -DWITH_OPENCL=OFF -DWITH_CUDA=OFF -DBUILD_SHARED_LIBS=ON -DBUILD_TESTS=OFF -DBUILD_PERF_TESTS=OFF  \
    -DBUILD_ZLIB=ON -DCV_TRACE=OFF -DCMAKE_INSTALL_PREFIX=$OPENCV_DIR/install \
    ../

else
    echo "unsupport toolchain: $TOOLCHAIN"
    exit -1
fi

rc=$?
if [[ $rc != 0 ]]; then
   exit -1 
fi


make -j8 && make install
