## OpenCV: Open Source Computer Vision Library

### Resources

* Homepage: <https://opencv.org>
* Docs: <https://docs.opencv.org/master/>
* Q&A forum: <http://answers.opencv.org>
* Issue tracking: <https://github.com/opencv/opencv/issues>

### build linux
bash build_linx.sh gcc 
bash build_linx.sh clang


### build android
bash cmake_android_arm.sh clang arm64
bash cmake_android_arm.sh clang v7
bash cmake_android_arm.sh gcc arm64
bash cmake_android_arm.sh gcc v7
