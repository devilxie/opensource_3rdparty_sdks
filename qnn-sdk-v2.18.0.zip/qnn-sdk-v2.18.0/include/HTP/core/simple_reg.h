//==============================================================================
//
// Copyright (c) 2023 Qualcomm Technologies, Inc.
// All Rights Reserved.
// Confidential and Proprietary - Qualcomm Technologies, Inc.
//
//==============================================================================

// We need the specific order for these headers
// clang-format off
#include "simple_op.h"
#include "ops_opts_registration.h"
// clang-format on
