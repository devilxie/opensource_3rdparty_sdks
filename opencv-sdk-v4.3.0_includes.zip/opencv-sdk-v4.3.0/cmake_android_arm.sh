#!/bin/sh

FILEPATH=$(realpath $0)
CD=`dirname "$FILEPATH"`
cd $CD
CD=$(pwd)
OPENCV_DIR=$CD

TOOLCHAIN=$1
ARCH=$2
ABI=

if [ -z "$ARCH" -o "$ARCH" = "arm64" ];then
    ABI=arm64-v8a
else
    ABI="armeabi-v7a with NEON"
fi

if [ -z "$TOOLCHAIN" ];then
   TOOLCHAIN=clang
fi

mkdir -p build_android_arm
cd build_android_arm

export ANDROID_SDK_ROOT=/home/sensetime/dev/jenkins/AndroidSdk

if [ "$TOOLCHAIN" = "clang" ];then
NDK_PATH=/data/android-ndk-r23b

/usr/local/bin/cmake -DANDROID_TOOLCHAIN=clang -DANDROID_NDK=$NDK_PATH -DANDROID_ABI=$ABI -DANDROID_TOOLCHAIN_NAME=-clang3.8 \
    -DBUILD_ANDROID_PROJECTS=OFF \
    -DOPENCV_EXTRA_MODULES_PATH=/data/project/opencv-4.3.0/opencv_contrib-4.3.0/modules \
    -DOPENCV_ENABLE_NONFREE=YES \
    -DANDROID_STL=c++_static -DCMAKE_TOOLCHAIN_FILE=$NDK_PATH/build/cmake/android.toolchain.cmake \
    -DOPENCV_DIR=$OPENCV_DIR -DCMAKE_BUILD_TYPE=Release -DBUILD_ANDROID_EXAMPLES=OFF \
    -DBUILD_DOCS=OFF -DBUILD_EXAMPLES=OFF -DWITH_CUDA=OFF -DWITH_TBB=OFF -DWITH_IPP=OFF -DBUILD_opencv_world=ON \
    -DBUILD_FAT_JAVA_LIB=OFF \
    -DBUILD_opencv_videoio=ON \
    -DWITH_WEBP=OFF \
    -DWITH_PROTOBUF=OFF \
    -DWITH_CAROTENE=OFF \
    -DBUILD_opencv_gapi=OFF \
    -DANDROID_PLATFORM=android-21 \
    -DOPENCV_FORCE_3RDPARTY_BUILD=ON \
    -DWITH_OPENCL=ON -DWITH_CUDA=OFF -DBUILD_SHARED_LIBS=OFF -DBUILD_TESTS=OFF -DBUILD_PERF_TESTS=OFF  \
    -DBUILD_ZLIB=ON -DCV_TRACE=OFF -DCMAKE_INSTALL_PREFIX=$OPENCV_DIR/install \
    ../

elif [ "$TOOLCHAIN" = "gcc" ];then

NDK_PATH=/data/android-ndk-r14b

/usr/local/bin/cmake -DANDROID_TOOLCHAIN=gcc -DANDROID_NDK=$NDK_PATH -DANDROID_ABI=$ABI -DANDROID_TOOLCHAIN_NAME=-4.9 \
    -DBUILD_ANDROID_PROJECTS=OFF \
    -DOPENCV_EXTRA_MODULES_PATH=/data/project/opencv-4.3.0/opencv_contrib-4.3.0/modules \
    -DOPENCV_ENABLE_NONFREE=YES \
    -DBUILD_opencv_world=ON \
    -DBUILD_FAT_JAVA_LIB=OFF \
    -DWITH_CAROTENE=OFF \
    -DOPENCV_FORCE_3RDPARTY_BUILD=ON \
    -DBUILD_opencv_videoio=ON -DBUILD_opencv_gapi=OFF \
    -DANDROID_STL=gnustl_static -DCMAKE_TOOLCHAIN_FILE=$NDK_PATH/build/cmake/android.toolchain.cmake \
    -DOPENCV_DIR=$OPENCV_DIR -DCMAKE_BUILD_TYPE=Release -DBUILD_ANDROID_EXAMPLES=OFF \
    -DBUILD_DOCS=OFF -DBUILD_EXAMPLES=OFF -DWITH_CUDA=OFF -DWITH_TBB=OFF -DWITH_IPP=OFF \
    -DWITH_OPENCL=ON -DWITH_CUDA=OFF -DBUILD_SHARED_LIBS=OFF -DBUILD_TESTS=OFF -DBUILD_PERF_TESTS=OFF  \
    -DBUILD_ZLIB=ON -DCV_TRACE=OFF -DCMAKE_INSTALL_PREFIX=$OPENCV_DIR/install \
    ../

else
    echo "unsupport toolchain: $TOOLCHAIN"
    exit -1
fi

rc=$?
if [[ $rc != 0 ]]; then
   exit -1 
fi


make -j8 && make install
